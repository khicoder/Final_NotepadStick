package com.sticky.khizra.notepadstick;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import static java.lang.System.currentTimeMillis;


public class Note extends AppCompatActivity {

    Button save,show_list;
    EditText title, input;
    TextView date_time;
    MyDatabase created_db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tut);


        //mTopToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        ///setSupportActionBar(mTopToolbar);

        title= (EditText) findViewById(R.id.notes_title);
        input= (EditText) findViewById(R.id.message);
        save = (Button) findViewById(R.id.btn);
       // show_list = (Button) findViewById(R.id.show);
        date_time = (TextView)findViewById(R.id.current_date_view);

        created_db = new MyDatabase(this);

   //final String cur_date = DateFormat.getDateTimeInstance().format(new Date());


        //  getActivity().getActionBar().setDisplayHomeAsUpEnabled(true);

        // part of the process of enabling the options menu, which includes the
        // back/up button. see onOptionsItemSelected(menu) for handling.
        //setHasOptionsMenu(true);
        date_time.setText( new SimpleDateFormat("yyyy-MM-dd HH:mm").format(new Date()));

         save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String n_title = title.getText().toString();
                final String newNote = input.getText().toString();

                if(input.length()!= 0 ){
                  //  onBackPressed();

    InsertNotes(n_title, newNote, new SimpleDateFormat("yyyy-MM-dd HH:mm").format(new Date()));
                       title.setText("");
                        input.setText("");
                        date_time.setText("");
                     }else{
                    Toast.makeText(Note.this, "You must put something in the text field!", Toast.LENGTH_LONG).show();
                }
            }
        });

/*       show_list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Note.this, MainActivity.class);
                startActivity(intent);
            }
        });*/


    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_note, menu);

        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case R.id.share_note: //////For Sharing any notes....


                Intent share_note =   new Intent(android.content.Intent.ACTION_SEND);
                share_note.setType("text/plain");
                share_note.putExtra(Intent.EXTRA_SUBJECT,"Insert Subject here");
                final String newNote = input.getText().toString();
                share_note.putExtra(android.content.Intent.EXTRA_TEXT,newNote);
                startActivity(Intent.createChooser(share_note, "Share via"));

            return(true);

        }
        return(super.onOptionsItemSelected(item));
    }
    public void onBackPressed(){
        final String newNote = input.getText().toString();
        final String n_title = title.getText().toString();
        if(input.length()!= 0)
            {
                InsertNotes(n_title,newNote, new SimpleDateFormat("yyyy-MM-dd HH:mm").format(new Date()));
                title.setText("");
                input.setText("");
                date_time.setText("");
            }
        Intent go_home = new Intent(Note.this, MainActivity.class);
        startActivity(go_home);
    }

    public void InsertNotes(String n_title, String newNote, String cur_date) {

        boolean insertData = created_db.InsertNewNote(n_title, newNote, new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));

        if(insertData) {
          //  Toast.makeText(this, "Data Successfully Inserted!", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Note.this, MainActivity.class);
            startActivity(intent);
        }else{
            Toast.makeText(this, "Something went wrong :(.", Toast.LENGTH_LONG).show();
        }
    }



}
