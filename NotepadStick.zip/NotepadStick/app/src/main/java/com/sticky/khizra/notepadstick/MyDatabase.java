package com.sticky.khizra.notepadstick;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.view.View;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Locale;

/**
 * Created by Mitch on 2016-05-13.
 */
public class MyDatabase extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "mylist.db";
    public static final String TABLE = "mylist_data";
    public static final String ID = "_id";
    public static final String COL_title = "ITEM1";
    public static final String COL_notes = "ITEM2";
    public static final String COl_date = "ITEM3";


    public MyDatabase(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE
                + " (" + ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                " " + COL_title + " TEXT," +
                " " + COL_notes + " TEXT," +
                " " + COl_date + " TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE);
        onCreate(db);
    }

    private String getDateTime() {
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        Date date = new Date();
        return dateFormat.format(date);
    }

    public boolean InsertNewNote(String notes_title, String inserted_note, String dated) {
        // dated= System.currentTimeMillis();
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues content = new ContentValues();
        content.put(COL_title, notes_title);
        content.put(COL_notes, inserted_note);
        content.put(COl_date, dated);

        long result = db.insert(TABLE, null, content);

        //if data inserted incorrectly it will return -1
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public Cursor ShowAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("SELECT * FROM " + TABLE
                + " ORDER BY " + COl_date + " DESC ", null);
        return data;
    }
/*
    public Cursor getId(String title) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("SELECT " + ID + " FROM " + TABLE
                + " WHERE " + COL_title + " = " + title, null);
        return data;
    }*/



/*       public boolean DeleteNote(String id){
        SQLiteDatabase db = this.getWritableDatabase();
        db.rawQuery("DELETE FROM " + TABLE
              +" WHERE "  +ID +" = "+ id, null);
          // db.delete(TABLE, id, null);
       //  db.delete(TABLE, id,null);
        return true;
    }*/
public boolean DelAll(){
    SQLiteDatabase db = this.getWritableDatabase();
    db.delete(TABLE, null, null);
    return true;
}
    public boolean EditNote(long id, String notes_title, String note){
        SQLiteDatabase db = this.getWritableDatabase();
        db.rawQuery("UPDATE " + TABLE
                +" SET " +COL_title +" = "+ notes_title
                        + COL_notes + " = " + note
                        +COl_date +" = "+ getDateTime()
                        +" WHERE "+ id + "= "+id,
                null);

        return true;
    }
}