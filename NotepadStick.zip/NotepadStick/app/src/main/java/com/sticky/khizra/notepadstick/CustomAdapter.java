package com.sticky.khizra.notepadstick;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
// http://www.simplylearnprogramming.com/insert-data-sqlite-display-data-android-listview/5
//Insert data in to sqlite and display on Android Listview

////..implements View.OnClickListener
@SuppressWarnings("unchecked")
public class CustomAdapter extends BaseAdapter  {
    private Context context;

    private ArrayList<String> ID_Array;
    private ArrayList<String> TITLE_array;
    private ArrayList<String> DATE_array;

    public CustomAdapter(Context context, ArrayList<String> ID_Array, ArrayList TITLE_array, ArrayList DATE_array) {
        this.context = context;
        this.ID_Array = ID_Array;
        this.TITLE_array= TITLE_array;
        this.DATE_array=DATE_array;
    }
    public int getCount() {
        return ID_Array.size();
    }

    public Object getItem(int position) {
        return ID_Array.get(position);
    }

    public long getItemId(int position) {
        return position;
    }

    public View getView(int position, View convertView, ViewGroup viewGroup) {
        final    viewHolder holder;
        //MyDatabase controllerdb =new MyDatabase(context);
        LayoutInflater layoutInflater;
        if (convertView == null) {
            layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.content_main, null);
            holder = new viewHolder();
            holder.id = (TextView) convertView.findViewById(R.id.n_id);
            holder.name = (TextView) convertView.findViewById(R.id.txt1);
            holder.mail = (TextView) convertView.findViewById(R.id.date_txt);
          //  holder.age = (TextView) convertView.findViewById(R.id.tvage);
            convertView.setTag(holder);
        } else {
            holder = (viewHolder) convertView.getTag();
        }
        holder.id.setText(ID_Array.get(position));
        holder.name.setText(TITLE_array.get(position));
        holder.mail.setText(DATE_array.get(position));
       // holder.age.setText(Age.get(position));
        return convertView;
    }
    public class viewHolder {
        TextView id;
        TextView name;
        TextView mail;
      //  TextView age;
    }
}