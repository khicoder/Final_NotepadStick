package com.sticky.khizra.notepadstick;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class UpdateNote extends AppCompatActivity {
    Button save,show_list;
    EditText title, input;
    TextView date_time;
    MyDatabase created_db;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.update_note);

      final   String selectedName;
       final   int selectedID;

        title= (EditText) findViewById(R.id.notes_title);
        input= (EditText) findViewById(R.id.message);
        save = (Button) findViewById(R.id.btn);
        // show_list = (Button) findViewById(R.id.show);
        date_time = (TextView)findViewById(R.id.current_date_view);

        created_db = new MyDatabase(this);

        date_time.setText( new SimpleDateFormat("yyyy-MM-dd HH:mm").format(new Date()));


//get the intent extra from the ListDataActivity
        Intent receivedIntent = getIntent();

        //now get the itemID we passed as an extra
        selectedID = receivedIntent.getIntExtra("id",-1); //NOTE: -1 is just the default value

        //now get the name we passed as an extra
        selectedName = receivedIntent.getStringExtra("name");

        //set the text to show the current selected name
        title.setText(selectedName);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String item = title.getText().toString();
                if(!item.equals("")){
                    created_db.EditNote(selectedID, item,selectedName);
                }
            }
        });

/*        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mDatabaseHelper.deleteName(selectedID,selectedName);
                editable_item.setText("");
                toastMessage("removed from database");
            }
        });*/

    }}