package com.sticky.khizra.notepadstick;

import android.content.Intent;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.widget.SimpleCursorAdapter;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;

import android.widget.GridView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.app.SearchManager;
import android.widget.SearchView;
import android.widget.SearchView.OnQueryTextListener;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


// For Color picker library
// https://android-arsenal.com/details/1/3324#!description
// Created byVladislav Bauer
// © 2014-2018 - Android Arsenal



/**
 * https://www.youtube.com/watch?v=nY2bYJyGty8&t=34s
 * CodingWithMitch
 * Published on Mar 2, 2017
 *   Editing and deleting data from an SQLite database [Beginner Android Studio Example]
 */
public class MainActivity extends AppCompatActivity {
    Button del;
    SearchView searchView;
    TextView n_id, dat, note;
    MyDatabase created_db;
    private ArrayAdapter<String> mAdapter;
    private GridView listView;
    private ArrayList<String> ID_Array= new ArrayList<String>();
    private ArrayList<String> TITLE_Array = new ArrayList<String>();
    private ArrayList<String> DATE_Array = new ArrayList<String>();
    ListAdapter listAdapter;

    public ListAdapter getListAdapter() {
        return listAdapter;
    }

    ;
    private static final String TAG = "MainActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note);

        del = (Button) findViewById(R.id.task_delete);
        n_id = (TextView) findViewById(R.id.n_id);
        note = (TextView) findViewById(R.id.txt1);
        dat = (TextView) findViewById(R.id.date_txt);

        listView = (GridView) findViewById(R.id.list_notes);
        created_db = new MyDatabase(this);

        ID_Array = new ArrayList<String>();

        TITLE_Array = new ArrayList<String>();

        DATE_Array = new ArrayList<String>();

        //populate an ArrayList<String> from the database and then view it
        final ArrayList<String> theList = new ArrayList<>();
        final Cursor data = created_db.ShowAllData();
        ID_Array.clear();
        TITLE_Array.clear();
        DATE_Array.clear();
//////String[] total= new String[data.getCount()];
        if (data.getCount() == 0) {
            Toast.makeText(this, "No notes added..", Toast.LENGTH_LONG).show();
        } else {

            while (data.moveToNext()) {///int i=0;
                ID_Array.add(data.getString(data.getColumnIndex(created_db.ID)));

               TITLE_Array.add(data.getString(data.getColumnIndex(created_db.COL_title)));

               DATE_Array.add(data.getString(data.getColumnIndex(created_db.COl_date)));

               // int cid =data.getInt(data.getColumnIndex(created_db.ID));
             //   String col_title = data.getString(data.getColumnIndex(created_db.COL_title));
               // String  col_date = data.getString(data.getColumnIndex(created_db.COl_date));
//del.setId(cid);
                //   col_note = total[i] ;
                // total[i] =col_date;
                //i++;
  // theList.add(col_note);
             //  theList.add(  + " " +  + " \n Last edit: " + DATE_Array+" \n");
       CustomAdapter ca = new CustomAdapter(MainActivity.this, ID_Array, TITLE_Array, DATE_Array);

                //theList.add(col_note);
             //   theList.add(col_date);

//                   String[] from = {note.getText().toString(),dat.toString()};
                 //  int[] to= {R.id.txt1, R.id.date_txt};
             //   final ListAdapter listAdapter;
                //  listAdapter= new SimpleAdapter(this, theList, R.layout.content_main, from, to);
                // listAdapter = new ArrayAdapter<String>(this, R.layout.content_main, to, new int[] {R.id.txt1, R.id.date_txt}, theList);
                //listAdapter = new ArrayAdapter<>(this, R.layout.content_main, to, theList);
            //   listAdapter = new ArrayAdapter<>(this, R.layout.content_main, theList);
            //    listAdapter = new ListAdapter(this,ID_Array,
              //        TITLE_Array,
                //    DATE_Array);
               listView.setAdapter(ca);


             //   String[] from = new String[] { col_title, col_date};
              //  int[] to = new int[] { R.id.txt1 ,R.id.date_txt};

                // Now create an array adapter and set it to display using our row
            /* ..  SimpleCursorAdapter notes =
                       new SimpleCursorAdapter(this, R.layout.content_main, data, from, to,0);
             */ // listView.setAdapter(notes);




                //listView.setId(cid);
//int sizee= theList.size();
                //n
                // String[] row_items=  theList.get(position).split("__");

            }//while (data.moveToNext());

        }
/*        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override          //      created_db.DeleteNote(listView.getSelectedItemId());
            public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
//listView.get(pos);
*//*                String title = parent.getItemAtPosition(pos).toString();
              //  Log.d(TAG, "clicked on item: " + pos);
             // long txt = listView.getItemIdAtPosition();
                //final Cursor data = created_db.ShowAllData();

//////String[] total= new String[data.getCount()];
Cursor data= created_db.getId(title);
int n_id=-1;
while (data.moveToNext())
{
    n_id= data.getInt(0);
}
       if(n_id > -1)
        {
            Toast.makeText(MainActivity.this,
                    "Item  id" + n_id, Toast.LENGTH_LONG).show();


            Intent mintent = new Intent(MainActivity.this, UpdateNote.class);
            mintent.putExtra("ID",n_id);
            mintent.putExtra("title",title);
            startActivity(mintent);
        }
                        //  int cid =data.getInt(data.getColumnIndex(created_db.ID));
      *//*                 // String col = data.getString(data.getColumnIndex(created_db.ID));

            }

        });*/
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                //     .setAction(Intent, null).show();
                Intent mintent = new Intent(MainActivity.this, Note.class);
                startActivity(mintent);
            }
        });


    }

    /* (Searchbar functionality)
     onCreateOptionsMenu() is taken from youtube vedio tutorial
    * https://www.youtube.com/watch?v=jJYSm_yrT7I
    * By: Tihomir RAdeff
    * Published on Dec 21, 2016
    * */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);

  /*      MenuItem search_item= menu.findItem(R.id.search_bar);
        SearchView sv= (SearchView) getActionView(search_item);
        //// 'getActionView(MenuItem):View' is deprecated
        sv.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }*/

/*            @Override
            public boolean onQueryTextChange(String newText) {
                ArrayList<String> templist= new ArrayList<>();
               *//* for (String temp: theList)
                    if (temp.toLowerCase().contains(newText.toLowerCase()))
                    {
                        templist.add(temp);
                    }*//*
                return false;
            }*/
     //   });
        return true;
    }

            @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {

        case R.id.del: //////For deleting all notes....
            created_db.DelAll();
            refresh_page();
            // TextView count=(TextView)findViewById(R.id.);
           // count.setText("Add is clicked");
            return(true);

        case R.id.search_bar:
                return true;

    }
        return(super.onOptionsItemSelected(item));
    }
/*    public void deleteNote(View view) {
        View parent = (View) view.getParent();
        TextView taskTextView = (TextView) parent.findViewById(R.id.txt1);
        String task = String.valueOf(taskTextView.getText());
        created_db.DeleteNote(task);
       refresh_page();
    }*/
private void refresh_page()
{
    final ArrayList<String> theList = new ArrayList<>();
    final ArrayAdapter adapter;
    adapter = new ArrayAdapter<>(this, R.layout.content_main, R.id.txt1, theList);

    listView.setAdapter(adapter);
    adapter.notifyDataSetChanged();///Use to Refresh the page...
}


}
